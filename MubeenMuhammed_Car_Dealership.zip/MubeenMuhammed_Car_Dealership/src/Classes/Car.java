package Classes;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.InputMismatchException;
import java.util.Map;
import java.util.Scanner;

//Class for performing operations on Cars
public class Car {

	String color;		//color of car
	int regNo;			//Registration number of car
	String model;		//Model of car

	ArrayList<Car> carList = new ArrayList<Car>();
	ArrayList<Car> carList2 = new ArrayList<Car>();
	Dealership dealerShipObj = new Dealership();
	public ArrayList<String> newDealerShipList = new ArrayList<String>();
	HashMap<String, ArrayList<Car>> newDealerVsCarHashMap = new HashMap<String, ArrayList<Car>>();
	
	//default constructor
	public Car() {

	}
	
	//Another constructor
	public Car(String color, int regNo, String model) {
		this.color = color;
		this.regNo = regNo;
		this.model = model;
	}
	
	//Car constructor
	public Car(ArrayList<String> obj, HashMap<String, ArrayList<Car>> obj2) {
		this.newDealerShipList = obj;
		this.newDealerVsCarHashMap = obj2;
	}

	//Add new Car to be sold by dealer
	public int makeAddNewCar() {
		System.out.println("Enter the make of car to add.");
		int cnt = 1;
		for (String manufactName : newDealerShipList) {
			System.out.println(cnt + " : " + manufactName);
			cnt = cnt + 1;
		}

		Scanner sc = new Scanner(System.in);
		
		int addCarOption = -1;
		
		//For handling the Input mismatch
		try {
			addCarOption = sc.nextInt();
		} catch (Exception e1) {
			System.out.println("***************EXCEPTION**************");
			System.out.println("Enter integer only");
			return 0;
		}
		
		//CHecking if the option is in correct range
		if(((addCarOption) > newDealerShipList.size()) || ((addCarOption) < 1)) {
			System.out.println("Error: Enter choice within the range");
			return 0;
		}
		System.out.println("\nMake to be added = " + newDealerShipList.get(addCarOption  - 1));
		String addMakeName = newDealerShipList.get(addCarOption - 1);
		System.out.println("\nEnter Registration number of car.");
		int thisRegNo = -1 ;
		try {
			thisRegNo = sc.nextInt();
		}catch(InputMismatchException e) {
			System.out.println("\nError: The input should be an Integer");
			return 0;
		}
		
		System.out.println("\nEnter model of car.");
		String thisModel = sc.next();
		System.out.println("\nEnter color of car");
		String thisColor = sc.next();
		
		
		if (addCarOption <= newDealerShipList.size()) {
			Car car = new Car(thisColor, thisRegNo, thisModel);		//Creating object of new car
			ArrayList<Car> carFeatureList = new ArrayList<Car>();
			if (null != newDealerVsCarHashMap.get(addMakeName)) {
				carFeatureList = newDealerVsCarHashMap.get(addMakeName);
			} else {
				carFeatureList = new ArrayList<Car>();
			}
			carFeatureList.add(car);		//Adding car object to the list
			
			for (Car temp : carFeatureList) {
				System.out.println(temp.color + " , " + temp.model + " , " + temp.regNo);
			}
			newDealerVsCarHashMap.put(addMakeName, carFeatureList);
			dealerShipObj.setDealerVsCarHashMap(newDealerVsCarHashMap);
			
		} else {

		}
		return 1;
	}
	
	//display hashmap
	public void displayHashmap() {
		System.out.println("\n************* DISPLAY ************");
		for (Map.Entry<String, ArrayList<Car>> manufactVsCarDetail : newDealerVsCarHashMap.entrySet()) {
			System.out.println("\nMake of car : " + manufactVsCarDetail.getKey());
			ArrayList<Car> carList = manufactVsCarDetail.getValue();
			if(carList.size()==0) {
				System.out.println("\nNo cars found");
			}
			else {
			for (Car obj : carList) {
				System.out.println("color : " + obj.color + ", regno : " + obj.regNo + ", model : " + obj.model);
			}}
		}
	}
	
	//Remove the car entry
	public int removeCar() {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter option for make of car : ");
		int cnt = 1;
		for (String manufactName : newDealerShipList) {
			System.out.println(cnt + " : " + manufactName);
			cnt = cnt + 1;
		}
		
		
		
		
		int num = -1;
		try {
			num = sc.nextInt();
		} catch (InputMismatchException e1) {
			System.out.println("***************EXCEPTION**************");
			System.out.println("\nError: The input should be an Integer only");
			return 0;
		}
		//Checking if the input is in correct range or not
		if(((num) > newDealerShipList.size()) || ((num) < 1)) {
			System.out.println("\nError: The input should be within range");
			return 0;
		}
		
		String makeOfCar = newDealerShipList.get(num - 1);
		
		System.out.println("make of car to be deleted : " + makeOfCar);
		System.out.println("Enter reg no : ");
		
		int registerNo = -1;
		try {
			registerNo = sc.nextInt();
		} catch (InputMismatchException e1) {
			System.out.println("***************EXCEPTION**************");
			System.out.println("\nError: The input should be an Integer only");
			return 0;
		}
		
		carList = newDealerVsCarHashMap.get(makeOfCar);
		int r = 0;
		boolean flag = false;
		for (Car obj : carList) {
			if (obj.regNo == (registerNo)) {
				flag = true;
			}
			else
			{
				carList2.add(obj);
			}
			r = r+1;
		}
		if(!flag)
		{
			newDealerVsCarHashMap.put(makeOfCar, carList2);
			System.out.println("\nThe requested car is not found. Please enter correct registration number");
			return 0;
		}
		else {
			System.out.println("\n****Deleted successfully****");
			newDealerVsCarHashMap.put(makeOfCar, carList2);
			return 1;
		}
	}
	
	//Display all cars of a manufacturer
	public void displayAllCarsOfManufacturer()
	{
		System.out.println("Enter option of manufacturer : ");		
		int cnt = 1;
		Scanner sc = new Scanner(System.in);
		for (String manufactName : newDealerShipList) {
			System.out.println(cnt + " : " + manufactName);
			cnt = cnt + 1;
		}
		int Option = -1;
		try {
			Option = sc.nextInt();
		} catch (InputMismatchException e1) {
			System.out.println("***************EXCEPTION**************");
			System.out.println("\nError: The input should be an Integer only");
			return;
		}
		//Checking if the input is in correct range or not
		if(((Option) > newDealerShipList.size()) || ((Option) < 1)) {
			System.out.println("\nError: The input should be within range");
			return;
		}
		System.out.println("\nItem to display = " + newDealerShipList.get(Option - 1));
		String manu = newDealerShipList.get(Option - 1);
		
		ArrayList<Car> list = new ArrayList<Car>();
		list = newDealerVsCarHashMap.get(manu);
		int carNo = 1;
		if(list.size() == 0)
		{
			System.out.println("No cars found");
		}
		else {
		for (Car obj : list) {
			System.out.println("Car No : "+ carNo);
			System.out.println("Regno : " + obj.regNo + ", color : " + obj.color +  ", model : " + obj.model);
			carNo = carNo + 1;
		}
		}
	}
	
	public void numberOfMakeModel()
	{
		System.out.println("Enter option of manufacturer : ");		
		int cnt = 1;
		Scanner sc = new Scanner(System.in);
		for (String manufactName : newDealerShipList) {
			System.out.println(cnt + " : " + manufactName);
			cnt = cnt + 1;
		}
		
		int Option = -1;
		
		try {
			Option = sc.nextInt();
		} catch (InputMismatchException e1) {
			System.out.println("***************EXCEPTION**************");
			System.out.println("\nError: Enter Integer only");
			return;
		}
		
		if(((Option) > newDealerShipList.size()) || ((Option) < 1)) {
			System.out.println("\nError: The input should be within correct range");
			return;
		}
		System.out.println("Item to display = " + newDealerShipList.get(Option - 1));
		String manu = newDealerShipList.get(Option - 1);
		System.out.println(manu);
		System.out.println("Enter model name");
		String m = sc.next();
		
		ArrayList<Car> list = new ArrayList<Car>();
		
		boolean flag = false;
		list = newDealerVsCarHashMap.get(manu);
		System.out.println("************* DISPLAY ************");
		int carNo = 1;		//Printing the details of the car
		int count_cars = 0;
		
		
		for (Car obj : list) {
			if(obj.model.equalsIgnoreCase(m))
			{
				count_cars = count_cars + 1;
			}
		}
		System.out.println("\nThere are "+ count_cars+ " cars present of the model.");
		
		for (Car obj : list) {
			if(obj.model.equalsIgnoreCase(m))
			{
				System.out.println("Car No : "+ carNo);
				System.out.println("Regno : " +  obj.regNo + ", color : " + obj.color + ", model : " + obj.model);
				carNo = carNo + 1;
				flag = true;
				count_cars = count_cars + 1;
			}
		}
		if(!flag) {
			System.out.println("\nSorry, The dealer does not have any car of that model.");
		}
		
	}
	//Display cars of particular manufacture and model 
	public void displayMakeManufacturer()
	{
		System.out.println("Enter option of manufacturer : ");		
		int cnt = 1;
		Scanner sc = new Scanner(System.in);
		for (String manufactName : newDealerShipList) {
			System.out.println(cnt + " : " + manufactName);
			cnt = cnt + 1;
		}
		
		int Option = -1;
		
		try {
			Option = sc.nextInt();
		} catch (InputMismatchException e1) {
			System.out.println("***************EXCEPTION**************");
			System.out.println("\nError: Enter Integer only");
			return;
		}
		
		if(((Option) > newDealerShipList.size()) || ((Option) < 1)) {
			System.out.println("\nError: The input should be within correct range");
			return;
		}
		System.out.println("Item to display = " + newDealerShipList.get(Option - 1));
		String manu = newDealerShipList.get(Option - 1);
		System.out.println(manu);
		System.out.println("Enter model name");
		String m = sc.next();
		
		ArrayList<Car> list = new ArrayList<Car>();
		
		boolean flag = false;
		list = newDealerVsCarHashMap.get(manu);
		System.out.println("************* DISPLAY ************");
		int carNo = 1;		//Printing the details of the car
		for (Car obj : list) {
			if(obj.model.equalsIgnoreCase(m))
			{
				System.out.println("Car No : "+ carNo);
				System.out.println("Regno : " +  obj.regNo + ", color : " + obj.color + ", model : " + obj.model);
				carNo = carNo + 1;
				flag = true;
			}
		}
		if(!flag) {
			System.out.println("\nSorry, The dealer does not have any car of that model.");
		}
	}

}
