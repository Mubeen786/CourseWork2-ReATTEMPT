package Classes;

import java.util.InputMismatchException;
import java.util.Scanner;

//Class containing main funtion
public class MainClass {

	static DealershipTest dealershipTest = new DealershipTest();   //Object of dealershipTest class to work with manufacturing data
	static Dealership dealerShip = new Dealership();     //Object of dealership class

	public static void main(String[] args) throws Exception {
		
		dealershipTest.menu();

	}

}