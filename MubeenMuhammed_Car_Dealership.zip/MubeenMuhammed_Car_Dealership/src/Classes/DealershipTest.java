package Classes;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.InputMismatchException;
import java.util.Scanner;

//Class to implement operations on manufacturer 
public class DealershipTest {

	String manufacturerName;
	Dealership dealerShipObj = new Dealership();		//object of dealership class
	ArrayList<String> modelList = new ArrayList<String>();		//local list
	HashMap<String, ArrayList<Car>> modelDealerVsCarHashMap = new HashMap<String, ArrayList<Car>>();		//Local Hash Map object  
	BST tree;		//Local object for BST

	//Function to add new manufacturer in dealers list
	public void addManufacturer(String name) {
		modelList.add(name);
		dealerShipObj.setDealerShipList(modelList);
		if (!dealerShipObj.getDealerVsCarHashMap().containsKey(name)) {
			ArrayList<Car> allListCars = new ArrayList<Car>();
			modelDealerVsCarHashMap.put(name, allListCars);
			dealerShipObj.setDealerVsCarHashMap(modelDealerVsCarHashMap);
			System.out.println("\nSuccessfully added the manufacturer");
		}
		else
		{
			System.out.println("\nManufacturer already present");
		}
		
	}
	
	//Function to remove manufacturer from dealership list
	public void removeManufacturer(String name) {
		modelList.remove(name);
		dealerShipObj.setDealerShipList(modelList);
		modelDealerVsCarHashMap.remove(name);
		dealerShipObj.setDealerVsCarHashMap(modelDealerVsCarHashMap);
		System.out.println("Successfully Removed");
	}

	//Funtion to display all manufacturer available
	public void display() {
		
		//condition to check if the list is empty 
		if(dealerShipObj.getDealerShipList().size() == 0)
		{
			System.out.println("\nThe Dealer currently does not have any manufacturer. Please add manufacturer by pressing option 1");
			return;
		}
		System.out.println("\nAvailable Manufacturers in dealership:");
		int cnt = 1;
		System.out.println("************* DISPLAY ************");
		for (String manufactName : dealerShipObj.getDealerShipList()) {
			System.out.println(cnt+". " + manufactName);
			cnt = cnt +1;
		}
	}
	
	//function to display the hashmap
	public void displayHashmap() {
		System.out.println("************* DISPLAY ************");
		for (String key : dealerShipObj.getDealerVsCarHashMap().keySet()) {
			System.out.println("Key = " + key);
			System.out.println("Value = " + dealerShipObj.getDealerVsCarHashMap().get(key));
		}
	}
	
	//Function to display Removing options.
	public String displayRemoveOptions() throws Exception  {
		int cnt = 1;
		Scanner sc = new Scanner(System.in);
		for (String manufactName : dealerShipObj.getDealerShipList()) {
			System.out.println(cnt + " : " + manufactName);
			cnt = cnt + 1;
		}
		
		
		String op = "-1";
		try {
			int removeOption = sc.nextInt();
			System.out.println("Item to be deleted = " + dealerShipObj.getDealerShipList().get(removeOption - 1));
			op = dealerShipObj.getDealerShipList().get(removeOption - 1);
		}
		catch(Exception e) {
			throw new Exception("Exception message");
		}
		return op;
		
	}

	//Function to check whether a manufacturer is present or not
	public void checkIfPresent(String name) {
		
		System.out.println("************* DISPLAY ************");
		if (dealerShipObj.getDealerShipList().contains(name)) {
			System.out.println("\nThe dealer sells this manufacturer of car");
		} else {
			System.out.println("\nThe dealer does not sell this manufacturer.");
		}
		
	}

	//Function to add new car
	public void makeAddNewCar() {
		Car car = new Car(dealerShipObj.getDealerShipList(), dealerShipObj.getDealerVsCarHashMap());
		int r = car.makeAddNewCar();
		if(r == 1)
		{
			car.displayHashmap();
		}
	}

	//Function to remove a car
	public void removeCar() {
		Car car = new Car(dealerShipObj.getDealerShipList(), dealerShipObj.getDealerVsCarHashMap());
		int r = car.removeCar();
		if(r == 1) {
			car.displayHashmap();
		}
	}
	
	//Function to display all cars on the basis of manufacturer
	public void displayAllCarsManufacturer()
	{
		Car car = new Car(dealerShipObj.getDealerShipList(), dealerShipObj.getDealerVsCarHashMap());
		car.displayAllCarsOfManufacturer();
	}
	
	public void numberOfMakeModelDealer()
	{
		Car car = new Car(dealerShipObj.getDealerShipList(), dealerShipObj.getDealerVsCarHashMap());
		car.numberOfMakeModel();
	}
	
	//Display cars of particular make and model
	public void displayMakeManufacturer()
	{
		Car car = new Car(dealerShipObj.getDealerShipList(), dealerShipObj.getDealerVsCarHashMap());
		car.displayMakeManufacturer();
	}
	
	//Convert to binary search tree
	public void ConvertToBST()
	{
		System.out.println("\nDisplaying in alphabetical order");
		tree = new BST( dealerShipObj.getDealerShipList().get(0) );
		for (int i = 1; i<dealerShipObj.getDealerShipList().size();i++)
		{
			tree.insertNode(dealerShipObj.getDealerShipList().get(i));
		}
		
		tree.InOrderTraverse(dealerShipObj);
	}
	
	public void menu() throws Exception
	{
		while (true) {
		try {
			System.out.println(
					"\nMenu\n\n1. Add New manufacturer\n2. Remove Manufacturer\n3. Display All Manufacturers\n4. Check if manufacturer is present\n5. Add New Car"
							+ "\n6. Remove car\n7. Display All Cars of a manufacturer\n8. Display Car Make and model"
							+ "\n9.Convert to binary search tree and print manufacturers" + "\n10. Display number of cars available for specific make and model."+"\n Type 0 to exit");   //Menu for user
			Scanner sc = new Scanner(System.in);      
			int option = sc.nextInt();		//Taking input from user
			if (option == 0)			//To exit the code
			{
				System.out.println("\nExited successfully");
				System.out.println("Thank you for using the service");
				break;
			}
			if(option > 10) {
				System.out.println("\nError: Choice is not within range. Enter correct option");
			}
			switch (option) {
			case 1:			//Add manufacturer
				System.out.println("\nEnter Manufacturer name:");
				String manufacturerName = sc.next();
				addManufacturer(manufacturerName);
				break;
			case 2:			//Remove manufacturer
				System.out.println("\nEnter the option of manufacturer you want to remove");
				String op;
				try {
					op = displayRemoveOptions();		//Display the manufacturers sold by dealer.
					if (op != "-1")
					{
						removeManufacturer(op);			//Remove the manufacturer selected
					}
				} catch (Exception e) {
					System.out.println("\nSorry, Couldn't process that");
					System.out.println("Enter correct option!");
				}
				break;
			case 3:			//Condition to display all manufacturers
				display();
				break;
			case 4:			//Condition to check if manufacturer is sold by dealer
				System.out.println("\nEnter the manufacturer to check");
				String checkOp = sc.next();
				checkIfPresent(checkOp);
				break;
			case 5:			//Add new car to dealership sell list
				makeAddNewCar();
				break;
			case 6:			//Remove a car
				removeCar();
				break;
			case 7:			//Display all cars on the basis of manufacturer
				displayAllCarsManufacturer();
				break;
			case 8:			//Display all cars of particular Manufacturer and model
				displayMakeManufacturer();
				break;
			case 9:			//Convert the list to binary search tree
				ConvertToBST();
				System.out.println("\nConverted to Binary Search Tree");
				break;
			case 10:
				numberOfMakeModelDealer();
				break;
			}
			
		}
			catch(InputMismatchException e) {
				System.out.println("\nError: Only numbers accepted as option");
			}
	}
	}
}