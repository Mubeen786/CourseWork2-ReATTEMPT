package Classes;
import java.util.ArrayList;
import java.util.HashMap;

//Class containing data structure for manufacturer and cars
public class Dealership {
	public ArrayList<String> dealerShipList = new ArrayList<String>();
	HashMap<String, ArrayList<Car>> dealerVsCarHashMap = new HashMap<String, ArrayList<Car>>();
	
	public ArrayList<String> getDealerShipList() {
		return dealerShipList;
	}
	public void setDealerShipList(ArrayList<String> dealerShipList) {
		this.dealerShipList = dealerShipList;
	}
	public HashMap<String, ArrayList<Car>> getDealerVsCarHashMap() {
		return dealerVsCarHashMap;
	}
	public void setDealerVsCarHashMap(HashMap<String, ArrayList<Car>> dealerVsCarHashMap) {
		this.dealerVsCarHashMap = dealerVsCarHashMap;
	}
	
}
