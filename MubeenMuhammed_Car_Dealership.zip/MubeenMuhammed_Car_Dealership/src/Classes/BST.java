package Classes;

import java.util.ArrayList;
import java.util.HashMap;

//Class for Binary Search tree
public class BST {
	
	String data;		//data in the node
	BST leftChild;		//left node
	BST rightChild;		//right node
	BST checkTree;		//local tree object
	
	//Dealership dealerShipObj = new Dealership();		//object of dealership class
	
	//constructor
	public BST(String data) {
		this.data = data;
		this.leftChild = null;
		this.rightChild = null;
	}
	
	//Another constructor
	public BST(BST t)
	{
		this.checkTree = t;
	}

	//inserting a new node
	public void insertNode(String num) {
		
		int compare = num.compareToIgnoreCase(this.data);
		if(compare < 0) {
		
			if (this.leftChild != null) {
				this.leftChild.insertNode(num);
			} else {
				this.leftChild = new BST(num);
			}

		} else {
			if (this.rightChild != null) {
				this.rightChild.insertNode(num);
			} else {
				this.rightChild = new BST(num);
			}

		}
	}

	//Performing inorder traversal
	public void InOrderTraverse(Dealership dealerShipObj1) {
		Dealership dealerShipObj = new Dealership();		//object of dealership class
		dealerShipObj = dealerShipObj1;
		if (this.leftChild != null) {
			this.leftChild.InOrderTraverse(dealerShipObj);
		}
		System.out.println("\nManufacturer Name: "+this.data);
		if(dealerShipObj.getDealerVsCarHashMap().get(this.data).size()>0)
		{
			System.out.println("\nCars present are as follows: ");
		}
		for (int i = 0;i<dealerShipObj.getDealerVsCarHashMap().get(this.data).size(); i++)
		{
			System.out.println("Regno: "+dealerShipObj.getDealerVsCarHashMap().get(this.data).get(i).regNo+", Model name: "+dealerShipObj.getDealerVsCarHashMap().get(this.data).get(i).model+", Colour: "+dealerShipObj.getDealerVsCarHashMap().get(this.data).get(i).color);
		}
		if (this.rightChild != null) {
			this.rightChild.InOrderTraverse(dealerShipObj);
		}
	}
	
}